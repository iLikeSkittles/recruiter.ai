// Function to handle position and display corresponding questions
function handlePosition(position) {
    const questionsContainer = document.getElementById('questionsContainer');
    const answersContainer = document.getElementById('answersContainer');
  
    // Clear the existing questions and answers
    questionsContainer.innerHTML = '';
    answersContainer.innerHTML = '';
  
    // Define the job title variable based on the selected position
    let jobTitle;
    switch (position) {
      case 'Software Engineer':
        jobTitle = 'Software Engineer';
        // Rest of the code for the Software Engineer questions
        questions = [
          "How does the team collaborate and work together?",
          "What technologies and programming languages are commonly used?",
          "Are there any ongoing or upcoming software engineering projects?"
      ];
        break;
      case 'Data Analyst':
        jobTitle = 'Data Analyst';
        // Rest of the code for the Data Analyst questions
        questions = [
          "What type of data analysis projects or tasks will be expected in this role?",
          "What tools and technologies are commonly used for data analysis within the company?",
          "How does the company utilize data analysis to inform decision-making or drive business growth?"
      ];
        break;
      case 'Product Manager':
        jobTitle = 'Product Manager';
        // Rest of the code for the Product Manager questions
          questions = [
            "Can you describe the typical product development process within the company?",
            "What is the level of collaboration between product managers and other teams, such as engineering and design?",
            "How does the company prioritize and make decisions about which products or features to pursue?"
        ];
        break;
      default:
        jobTitle = ''; // Provide a default value if needed
        break;
    }
  
    // Initialize the answers object with the introductory message
    const answers = {
      introduction: `I am a recruiter for a business, I am recruiting for ${jobTitle}. Can you write me a job description based on the following questions and answers:`,
      questions: {},
    };
  
    // Display the introductory message
    const introductionElement = document.createElement('p');
    introductionElement.textContent = answers.introduction;
    questionsContainer.appendChild(introductionElement);
  
    // Display the questions and text fields for the answers
    const formElement = document.createElement('form');
    questions.forEach((questionText) => {
      const labelElement = document.createElement('label');
      labelElement.textContent = questionText;
  
      const inputElement = document.createElement('input');
      inputElement.type = 'text';
  
      const lineBreakElement = document.createElement('br');
  
      formElement.appendChild(labelElement);
      formElement.appendChild(inputElement);
      formElement.appendChild(lineBreakElement);
    });
  
    const submitButton = document.createElement('button');
    submitButton.type = 'submit';
    submitButton.textContent = 'Generate Job Description';
  
    formElement.appendChild(submitButton);
    questionsContainer.appendChild(formElement);
  
    // Add an event listener to the form submission event
    formElement.addEventListener('submit', function(event) {
      event.preventDefault();
  
      const inputs = formElement.querySelectorAll('input');
  
      // Store the answers in the answers object
      questions.forEach((questionText, index) => {
        const answer = inputs[index].value;
        answers.questions[questionText] = answer;
      });
  
      // Display the answers object as text
      const answersContainer = document.getElementById('answersContainer');
      answersContainer.textContent = JSON.stringify(answers, null, 2);
  
      // Optionally, you can send the answers to the ChatGPT API for further processing
  
      // Clear the input fields after storing the answers
      inputs.forEach((input) => {
        input.value = '';
      });
    });
  }